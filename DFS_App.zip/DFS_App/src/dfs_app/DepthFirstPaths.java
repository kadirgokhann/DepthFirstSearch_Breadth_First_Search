/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfs_app;
import java.util.*;
 
/**
 *
 * @author lenovo
 */
public class DepthFirstPaths {
    
    public int source;
    public boolean[] marked;
    public int[] edgeTo;
    
    public DepthFirstPaths(ListGraph g,int source)
    {
        this.source   = source;
        this.marked   = new boolean[g.getNumV()];
        this.edgeTo   = new int[g.getNumV()];
        for (int  i = 0; i < g.getNumV(); i++)
            this.edgeTo[i] = -1;
        dfs(g, source);
    }
    public void dfs(ListGraph g, int from){ 
        marked[from] = true;
        Integer[] numOfNeighbors;
        numOfNeighbors =(Integer[])g.neighborsArray(from);
        for(int i = 0; i < numOfNeighbors.length; i++)
        {
            int neighbor = numOfNeighbors[i]; 
            if(marked[neighbor] == false) 
            {
                dfs(g, neighbor);
                edgeTo[neighbor] = from;  
            }
        }
    } 
        
    public Stack<Integer> findPath(int w) //4 
    {  
        int k    = edgeTo[w]; //3 -> 4
        Stack st = new Stack<Integer>();
        st.push(k);
        while (k != this.source) 
        {
            k = edgeTo[k];
            st.push(k);
        }
        return st;
    }
    
    
    
    public boolean hasPathTo(int w)
    {
        return marked[w];
    }
}
