/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dfs_app;

import static dfs_app.ListGraph.readfromFile;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.logging.Level;
import java.util.logging.Logger;


/**
 *
 * @author lenovo
 */
public class DFS_App {


    public static void main(String[] args) {
        // TODO code application logic here
        ListGraph g1 = new ListGraph(9);
        g1.addEdge(0, 1);
        g1.addEdge(0, 2);
        g1.addEdge(2, 3);
        g1.addEdge(2, 4);
        g1.addEdge(4, 5);
        g1.addEdge(3, 6);
        g1.addEdge(4, 6);
        g1.addEdge(7, 8);
        System.out.println("Printing graph");
        System.out.println(g1.toString());
        //ListGraph g2 = readfromFile("graph1.txt");
        //System.out.println(g2.toString());
        //bfs(g1, 6);
        
        DepthFirstPaths obje = new DepthFirstPaths(g1, 0);
        for(boolean i : obje.marked)
        {
            System.out.print(i + ", ");
        }
        System.out.println("");
        
        
        // 0,1,2,3,6,4,5
        // mkt  edgeTo
        // 0 T    -
        // 1 T    0
        // 2 T    0
        // 3 T    2
        // 4 T    6
        // 5 T    4   
        // 6 T    3
        // 7 F    -
        // 8 F    -
        
    
    
        for(int i : obje.edgeTo){
            System.out.print(i + ", ");
        }

    
    
    
    
    }
    
    
    
    
    
    
    public static void bfs(ListGraph g, int source) {
        boolean visited[] = new boolean[g.getNumV()];
        // Create a queue for BFS
        LinkedList<Integer> queue = new LinkedList<Integer>();
        queue.add(source);
        visited[source] = true;
        while (!queue.isEmpty()) {
            // Dequeue a vertex from queue and print it
            source = queue.poll();
            System.out.print(source + " ");
            Iterator<Integer> i = g.neighborsList(source).listIterator();
            while (i.hasNext()) {
                int n = i.next();
                if (!visited[n]) {
                    visited[n] = true;
                    queue.add(n);
                }
            }
        }
    }
    
}
/*
marked[source] = true;
queue.addLast(source);
        while (! queue.isEmpty()) {
            source= queue.removeFirst();
            a = (Integer[]) g.neighborsArray(source);
            for (int i = 0; i < a.length; i++) {
                int w = a[i];
                if (!marked[w]){
		queue.addLast(w);
		marked[w] = true;
		edgeTo[w] = source;
		distTo[w] = distTo[source] + 1;
                }
            }}
}
*/